from firebase_functions import https_fn
from firebase_admin import initialize_app
import json

from firebase_functions import firestore_fn
from firebase_admin import firestore

import os
import openai
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.schema import StrOutputParser
from langchain.callbacks import get_openai_callback
import tiktoken

app = initialize_app()

@https_fn.on_request()
def add_preference(req: https_fn.Request) -> https_fn.Response:
    # get username & preference
    username = req.args.get("username")
    if username is None:
        return https_fn.Response("Username not provided", status=400)
    
    p_from = req.args.get("p_from")
    p_to = req.args.get("p_to")
    if (p_from is None) or (p_to is None):
        return https_fn.Response("Preference not provided", status=400)

    db = firestore.client()
    user = db.collection("users").document(username)

    # store user preference
    user.set({
        "preferences": {
            p_from: p_to
        }
    }, merge=True)

    # get updated translation
    r = {
        "username": username
    }
    result_updated = get_translation(r)
    print("* get_translation result received *")
    result_updated = json.loads(result_updated.data)

    # get similar ngram for recommendation
    os.environ['OPENAI_API_KEY'] = "" # openai key required
    llm = OpenAI(temperature=0, max_tokens=-1)

    template_5_ngrams = """
    Identify one ngram token that demonstrates the highest syntactic and semantic similarity to the source token.
    Ensure that the identified n-gram appears in the target text in the exact same form.
    Return the string only.
    For example, 2-point scale and 2-point system are highest similar ngrams.

    Source token: {sourcetoken}
    
    Target text: {targettext}

    Similar ngram:
    """
    prompt_5_ngrams = PromptTemplate.from_template(template_5_ngrams)
    chain_5_ngrams = prompt_5_ngrams | llm | StrOutputParser()
    
    try:
        print("* 5 get ngram *")
        with get_openai_callback() as cb:
            result_chain5 = chain_5_ngrams.invoke({"sourcetoken": p_from, "targettext": result_updated["targettext"]})
            print(result_chain5)
            print("\tTotal Tokens: ", cb.total_tokens, "\t(Prompt: ", cb.prompt_tokens, ")")
    except Exception as e:
        print("OpenAI Error:", e)
        result_chain5 = ""

    user.set({
        "ngram": result_chain5
    }, merge=True)

    # return all userdata
    u = user.get()
    result = u.to_dict()
    result_json = json.dumps(result)
    return https_fn.Response(result_json)

@https_fn.on_request()
def get_translation(req: https_fn.Request) -> https_fn.Response:
    # get username & source text
    try:
        username = req.args.get("username")
    except Exception as e:
        username = req["username"]
    if username is None:
        return https_fn.Response("Username not provided", status=400)
    
    db = firestore.client()
    user = db.collection("users").document(username)
    user.set({
        "username": username,
        "ngram": ""
    }, merge=True)

    try:
        text = req.args.get("text")
        p = req.args.get("p")
        sourcetext = db.collection("documents").document(text).get()
        sourcetext = sourcetext.to_dict()[p]
        print("* 0 sourcetext loaded *")
        print(sourcetext)
        targettext = db.collection("documents").document(text).get()
        targettext = targettext.to_dict()[p+"_gt"]
        print("* 0 targettext loaded *")
        print(targettext)
    except Exception as e:
        u = user.get()
        u = u.to_dict()
        sourcetext = u["sourcetext"]
        print("* 0 only sourcetext loaded *")
        print(sourcetext)
        targettext = u["targettext"]
    if sourcetext is None:
        return https_fn.Response("Sourcetext not found", status=400)

    # get user preference
    try:
        u = user.get()
        u = u.to_dict()
        preferences = u["preferences"]
    except Exception as e:
        preferences = {}

    # get translation
    os.environ['OPENAI_API_KEY'] = "" # openai key required
    llm = OpenAI(temperature=0.1, max_tokens=2600)

    # template_1_translate = """
    # As a highly skilled English-Korean translator, translate the provided source text with accuracy and fluency.
    # - Accurately convey the meaning of the original text in your translation.
    # - Translate technical terms with the following domain-specific jargon in mind, preserving the original nuances.
    
    # Domain-specific terms: 인터페이스 그래픽 사용자 인터페이스 인간-컴퓨터 상호작용 사용자 경험 사용자 인터페이스 디자인 사용자 중심 설계 사용자 연구 사용성 사용성 평가 유용성 효율성 만족도 학습성 기억성 오류 발생 가능성 사용자 친화성 유희성 감성적 디자인 공감형 디자인 사회적 디자인 환경 친화적 디자인 햅틱 인터페이스 음성 인터페이스 시각 인터페이스 제스처 인터페이스 감각 인터페이스 증강 현실 가상 현실 혼합 현실 몰입형 인터페이스 대화형 AI 인공 지능 머신 러닝 자연어 처리 딥 러닝 컴퓨터 비전 로보틱스 사물 인터넷 웨어러블 모바일 웹 앱 소프트웨어 하드웨어 시스템 프로세스 방법론 디자인 연구 평가 개발 테스팅 배포 유지 보수 접근성 보조 기능 국제화 사용자 테스트 시뮬레이션 통계적 분석 감정적 요소 사회적 요소 환경적 요소 모바일 인터페이스 웨어러블 인터페이스 증강 현실/가상 현실 인터페이스 인공 지능 기반 인터페이스 햅틱 피드백 모션 캡처 자연어 처리 빅 데이터 분석

    # Source text: {sourcetext}

    # Target text:
    # """

    template_2_update = """
    As a highly skilled English to Korean translator, ensure that the provided target text aligns with my preferences.
    
    You will be given a JSON object containing keys and values. Replace all instances of keys with the corresponding value throughout the target text.
    The value can be either Korean or English.
    Ensure not to include the keys in the text.
    Do not include the preference if the exact word did not appear in the text.
    Make any necessary syntactic adjustments to ensure the translation remains grammatically correct and fluent.

    User preferences: {preferences}

    Target text before adjustment: {targettext}

    Target text after adjustment:
    """
    
    template_3_match = """
    For each Korean token in the target text, identify the most semantically similar token from the source text.
    Consider one token to be a single word without any spaces. Account for all meaningful tokens during the matching process.
    Return in valid JSON format, using the Korean token as the key and the corresponding English token as the value.
    
    Target text: {targettext}

    Source text: {sourcetext}

    Matches:
    """
    
    template_4_replace = """
    As a highly skilled English-Korean translator, your task is to identify and provide up to two alternative Korean synonyms for each Korean token in the target text.
    Consider only synonyms with semantic variety, excluding those that differ only in grammatical or syntactical structure.
    Ensure that the recommended synonyms are appropriate for the surrounding context.
    Return key-value pairs in valid JSON format, using the original token as the key and the corresponding synonyms as a list of values.

    Target text: {targettext}

    Replacement suggestions:
    """
    
    # prompt_1_translate = PromptTemplate.from_template(template_1_translate)
    prompt_2_update = PromptTemplate.from_template(template_2_update)
    prompt_3_match = PromptTemplate.from_template(template_3_match)
    prompt_4_replace = PromptTemplate.from_template(template_4_replace)

    # chain_1_translate = prompt_1_translate | llm | StrOutputParser()
    chain_2_update = prompt_2_update | llm | StrOutputParser()
    chain_3_match = prompt_3_match | llm | StrOutputParser()
    chain_4_replace = prompt_4_replace | llm | StrOutputParser()

    try:
        # with get_openai_callback() as cb:
            # print("* 1 translate *")
            # result_chain1 = chain_1_translate.invoke({"sourcetext": sourcetext})
            # print(result_chain1)
            # print("\tTotal Tokens: ", cb.total_tokens, "\t(Prompt: ", cb.prompt_tokens, ")")
        result_chain1 = targettext
        with get_openai_callback() as cb:
            print("* 2 update with preferences *")
            result_chain2 = chain_2_update.invoke({"targettext": result_chain1, "preferences": preferences})
            print(result_chain2)
            print("\tTotal Tokens: ", cb.total_tokens, "\t(Prompt: ", cb.prompt_tokens, ")")
        with get_openai_callback() as cb:
            print("* 3 match *")
            result_chain3 = chain_3_match.invoke({"targettext": result_chain2, "sourcetext": sourcetext})
            print(result_chain3)
            print("\tTotal Tokens: ", cb.total_tokens, "\t(Prompt: ", cb.prompt_tokens, ")")
        with get_openai_callback() as cb:
            print("* 4 replace *")
            result_chain4 = chain_4_replace.invoke({"targettext": result_chain2})
            print(result_chain4)
            print("\tTotal Tokens: ", cb.total_tokens, "\t(Prompt: ", cb.prompt_tokens, ")")
            
    except Exception as e:
        print("OpenAI: ", e)

    result_chain3 = json.loads(result_chain3)
    result_chain4 = json.loads(result_chain4)

    # store each subtask result
    user.update({
        "sourcetext": sourcetext,
        "targettext": result_chain2,
        "matched": result_chain3,
        "replacements": result_chain4
    })
    
    # return all user data
    u = user.get()
    result = u.to_dict()
    result_json = json.dumps(result)
    return https_fn.Response(result_json)

# @https_fn.on_request()
# def get_replacement(req: https_fn.Request) -> https_fn.Response: